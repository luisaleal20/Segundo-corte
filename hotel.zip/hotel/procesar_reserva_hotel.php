<?php
    
    $nombre = $_POST['txt_nombre'];
    $identificacion = $_POST['identificacion'];
    $numero_identi = $_POST['numero_identi'];
    $habitacion = $_POST['habitacion'];
    $acompa = $_POST['acompa'];
    $seleccion_acompa = $_POST['seleccion_acompa'];
    
    
    $precio_habitacion_general = 100000;
    $precio_acompanante = 30000;
    $porcentaje_suite = 0.10; 
    
    
    if ($habitacion == "General") { 
        $costo_habitacion = $precio_habitacion_general;
    } elseif ($habitacion == "Suite") { 
        $costo_habitacion = $precio_habitacion_general * (1 + $porcentaje_suite);
    } else {
        echo "Tipo de habitación no válido.";
        exit;
    }
    $nombre = $_POST['txt_nombre'];
    $identificacion = $_POST['identificacion'];
    $numero_identi = $_POST['numero_identi'];
    $habitacion = $_POST['habitacion'];
    $acompa = $_POST['acompa'];
    $seleccion_acompa = $_POST['seleccion_acompa'];
    
    
    $precio_habitacion_general = 100000;
    $precio_acompanante = 30000;
    $porcentaje_suite = 0.10; 
    
    
    if ($habitacion == "General") { 
        $costo_habitacion = $precio_habitacion_general;
    } elseif ($habitacion == "Suite") { 
        $costo_habitacion = $precio_habitacion_general * (1 + $porcentaje_suite);
    } else {
        echo "Tipo de habitación no válido.";
        exit;
    }
