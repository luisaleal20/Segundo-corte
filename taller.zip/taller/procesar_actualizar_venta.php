<?php
require "config/conex.php";

require "config/conex.php";


$cantidad = $_POST["cantidad"];
$valor = $_POST["valor"];
$total = $cantidad * $valor;


$sql="INSERT INTO ventas(cantidad, valor, total) VALUES(".$cantidad.",".$valor.",".$total.")";


if($dbh->query($sql))
{
    echo "Datos actualizados";
}else
{
    "Error actualizando";
 }
 ?>
