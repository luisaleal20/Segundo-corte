<?php
require "config/conex.php";

$nombre=$_POST["nombre"];
$papas=$_POST["papas"];

$total=$papas*1000;
 
$sql="INSERT INTO papas(nombre,cantidad, total) VALUES(".$nombre.",".$papas.",".$total.")";


if($dbh->query($sql))
{
    echo "Datos actualizados";
}else
{
    "Error actualizando";
 }
 ?>

