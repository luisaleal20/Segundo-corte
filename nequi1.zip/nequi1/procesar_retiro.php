<?php
require "config/conex.php";
$valor = $_POST ["txt_valor"];
$id_logueado = 10;
$sql="INSERT INTO transacciones(tipo_transaccion, value, user_origen, user_destino) VALUES (2, ".$valor.",".$id_logueado.", 0)";

$sql2= "UPDATE usuario
SET
saldo=(saldo-".$valor.")
WHERE 
id = 1";
if ($valor <= 0) {
    exit('El monto a consignar debe ser mayor que cero');
}



if($dbh->query($sql))
{
    echo "Transaccion registrada exitosamente";
}else{
    echo "Error registrada transaccion";
     }
     if($dbh->query($sql2))
{
    echo "<br>Saldo actualizado exitosamente";
}else{
    echo "<br>Error actualizando saldol";
     }
     ?>
